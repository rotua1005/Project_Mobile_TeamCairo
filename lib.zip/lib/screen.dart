import 'package:cth/Karyawan/login.dart';
import 'package:cth/Owner/Login.dart';
import 'package:flutter/material.dart';

class Screen extends StatefulWidget {
  const Screen({super.key});

  @override
  State<Screen> createState() => _ScreenState();
}

class _ScreenState extends State<Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.white10,Colors.white24,Color.fromARGB(255, 4, 87, 155)],)
        ),
        
        child: Padding(
          padding: const EdgeInsets.all(9.0),
          child: Column(
              children: <Widget>[
                Column(
                     mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 1),
              Image(image: AssetImage(
                "images/shop.png"),height: 338),
                SizedBox(height: 20,),
              Text("BRASTAGI ACC PONSEL",style: TextStyle(
                fontSize: 25,fontWeight: FontWeight.bold
              ),
              ),
            ],
                ),
                SizedBox(height: 20,),
                Column(
                  children: <Widget>[
                    MaterialButton(
                      minWidth: 350,
                      height: 60,
                      onPressed: () {
                           Navigator.push(context, MaterialPageRoute(builder: (context)=>  const LoginOwner()));
                      },
                      color: Color.fromARGB(255, 4, 87, 155),
                    shape : RoundedRectangleBorder(
                      side: BorderSide(
                        color: const Color.fromARGB(255, 4, 87, 155)
                      ),
                      borderRadius: BorderRadius.circular(50)
                    ),
                    child: Text("Owner",style: TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15,color: Colors.white,
                    ),),
                    ),
                    SizedBox(height: 20,),
                    Container(
                      child:  MaterialButton(
                       minWidth: 350,
                      height: 60,
                      onPressed: () {
                         Navigator.push(context, MaterialPageRoute(builder: (context)=>  const Login()));
                      },
                     color: Color.fromARGB(255, 249, 252, 255),
                    shape : RoundedRectangleBorder(
                      side: BorderSide(
                        color: const Color.fromARGB(255, 4, 87, 155)
                      ),
                      borderRadius: BorderRadius.circular(50)
                    ),
                    child: Text("Karyawan",style: TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15,
                    ),),
                    ),
                    )
                  ],
                )
              ],
            ),
        ),
        ),
    ));
  }
}