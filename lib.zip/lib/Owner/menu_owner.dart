import 'package:cth/Owner/ListAbsensi.dart';
import 'package:cth/Owner/noteOwer.dart';
import 'package:cth/Owner/profil.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class MenuOwner extends StatefulWidget {
  const MenuOwner({super.key});

  @override
  State<MenuOwner> createState() => _MenuOwnerState();
}

class _MenuOwnerState extends State<MenuOwner> {
     String _jk = "";
  TextEditingController controllerNama = TextEditingController();
  TextEditingController controllerPass = TextEditingController();
  TextEditingController controllerMoto = TextEditingController();

  void _pilihJk(String value) {
    setState(() {
      _jk = value;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 17, 36, 69),
        title: Text("Menu Owner"),
        actions: <Widget>[
          InkWell(
             onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => ProfilOwner()));
                          },
            child: ClipOval(
                        child: 
                        Image(image: AssetImage("images/Ellipse 1.png"),height: 20,width: 50,fit: BoxFit.cover,),
                ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        color: const Color.fromARGB(255, 17, 36, 69),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 1.0,vertical: 5),
          child: GNav(
            backgroundColor: const Color.fromARGB(255, 17, 36, 69),
            color: Colors.white,
            activeColor: Colors.white,
            tabBackgroundColor: Colors.grey.shade800,
            gap: 10,
            onTabChange: (index){
              print(index);
            },
            padding: EdgeInsets.all(12),
            tabs: [
            GButton(icon: Icons.home,text: "Home",onPressed: () {
                            // Navigator.push(context, MaterialPageRoute(builder: (context)=>  const Home()));
                          },),
            GButton(icon: Icons.shopping_cart_checkout,text: "Penjualan",onPressed: () {
                            // Navigator.push(context, MaterialPageRoute(builder: (context)=>  const Produk()));
                          },),
            GButton(icon: Icons.list_alt,text: "Absensi",onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>  ListAbsensi(
                                nama: 'Tomy Andreas',
                              pass: '',
                              alasan: controllerMoto.text,
                              jk: _jk,
                              )));
                          },),
            GButton(icon: Icons.note_alt_sharp,text: "Note",onPressed: () {
                             Navigator.push(context, MaterialPageRoute(builder: (context)=>  const NoteOwner()));
                          },),
          ]),
        ),
      ),
      body: SafeArea(
        child: Container(
            height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.white10,Colors.white24,Color.fromARGB(255, 4, 87, 155)],)
        ),
        child: Padding(
          padding: const EdgeInsets.all(9.0),
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                ),
               SizedBox(height: 1),
                Image(image: AssetImage(
                  "images/38.png"),height: 108),
                  SizedBox(height: 0,),
               Row(
                              children: [
                                 Text("\t  \t     Hello,",style: TextStyle(
                          fontSize: 25,fontWeight: FontWeight.bold, color: Colors.blueAccent
                        ),),
                              ],
                            ),
                             Row(
                              children: [
                                Text("\t \t\tWiliam Bill",style: TextStyle(
                          fontSize: 23,fontWeight: FontWeight.bold,
                    ),),
                              ],
                            ),
              Column(
                children: [ 
                  Row(
                mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                 Container(
                    width: 250,
                    height: 120,
                    decoration: BoxDecoration(
                       borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Color.fromARGB(255, 41, 41, 41),
                        width: 2
                      ),
                    ),
                    child: Center(
                      child: 
                      Text("Nama Karyawan Yang Aktif \n \n* Tomi Andreas \n * Risa Mia \n * Yani Tika"),
                      ),
                 ),
                 Padding(
                   padding: const EdgeInsets.all(0.0),
                   child: Container( 
                    child: Image(image: AssetImage("images/image 34.png"),height: 200,width: 200,fit: BoxFit.cover,)
                               ),
                 ),
                  ],
               ),],
              ),
                Row(
                mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                 Padding(
                   padding: const EdgeInsets.all(0.0),
                   child: Container( 
                    child: Image(image: AssetImage("images/image 35.png"),height: 210,width: 110,fit: BoxFit.cover,)
                               ),
                 ),
                 SizedBox(width: 30,),
                  Container(
                     width: 250,
                    height: 120,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Color.fromARGB(255, 41, 41, 41),
                        width: 2
                      ),
                    ),
                    child: Center(
                      child: 
                      Text("Produk Yang Terjual Hari ini \n\n* Antigores \t \t \t \t \t \t5 pcs \n* Casing Hp \t \t \t  \t \t12 pcs \n* Kabel Iphone \t \t \t 2 pcs"),
                      ),
                 ),
                  ],
               ),
               Row(
                children: [
                  Icon(Icons.star, color: Colors.yellow ,),
                  Text(" Best Product Of The Month",style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),)
                ],
               ),
               SizedBox(height: 12),
                Row(
                  children: [
                      SizedBox(width: 30),
                    Column(
                      children: [
                        Container(
                          width: 180,
                          height: 200,
                          decoration: BoxDecoration(
                            color: Colors.blueAccent,
                            borderRadius: BorderRadius.circular(15),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                spreadRadius: 3,
                                blurRadius: 10,
                                offset: Offset(0, 3)
                              )
                            ]
                          ),
                          child: 
                          Column( 
                            children: [
                     Image(image: AssetImage("images/rectangle 9.png"),width: 350,fit: BoxFit.cover,),
                     Text("\nCase Phone",style: TextStyle(fontWeight: FontWeight.bold),),
                    Row(
                     mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: Colors.yellow ,),
                        Icon(Icons.star, color: Colors.yellow ,),
                        Icon(Icons.star, color: Colors.yellow ,),
                        Icon(Icons.star, color: Colors.yellow ,),
                      ],
                    ),
                    
                            ], 
                          )
                        ),
                      ],
                    ),
                    SizedBox(width: 25,),
                     Column(
                      children: [
                       Container(
                          width: 180,
                          height: 200,
                          decoration: BoxDecoration(
                            color: Colors.blueAccent,
                            borderRadius: BorderRadius.circular(15),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                spreadRadius: 3,
                                blurRadius: 10,
                                offset: Offset(0, 3)
                              )
                            ]
                          ),
                          child: 
                          Column(
                           
                            children: [
                     Image(image: AssetImage("images/rectangle 15.png"),width: 350,fit: BoxFit.cover,),
                     Text("\nScreen Protector",style: TextStyle(fontWeight: FontWeight.bold),),
                    Row(
                     mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: Colors.yellow ,),
                        Icon(Icons.star, color: Colors.yellow ,),
                        Icon(Icons.star, color: Colors.yellow ,),
                        Icon(Icons.star, color: Colors.yellow ,),
                      ],
                    ),
                    
                            ], 
                          )
                        ),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
           ),
        ),
        ),
    );
  }
}




