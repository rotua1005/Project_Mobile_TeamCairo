import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NoteList extends StatefulWidget {
  @override
  _NoteListState createState() => _NoteListState();
}

class _NoteListState extends State<NoteList> {
  List<String> notes = [];

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  Future<void> _loadNotes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      notes = prefs.getStringList('notes') ?? [];
    });
  }

  Future<void> _saveNotes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('notes', notes);
  }

  void _addNote() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddNoteScreen()),
    );

    if (result != null) {
      setState(() {
        notes.add(result);
      });
      _saveNotes();
    }
  }

  void _deleteNote(int index) {
    setState(() {
      notes.removeAt(index);
    });
    _saveNotes();
  }

  void _editNote(int index) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditNoteScreen(note: notes[index]),
      ),
    );

    if (result != null) {
      setState(() {
        notes[index] = result;
      });
      _saveNotes();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 17, 36, 69),
        title: Text('Barang Kosong'),
        actions: [
          PopupMenuButton(
            icon: const Icon(Icons.more_horiz),
            itemBuilder: (context) => [
              PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.create_outlined, color: Colors.black),
                    Container(
                      margin: EdgeInsets.only(left: 10),
                      child: Text("Create"),
                    )
                  ],
                ),
                onTap: () {
                  // Handle 'Create' option tap
                },
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.list_outlined, color: Colors.black),
                    Container(
                      margin: EdgeInsets.only(left: 10),
                      child: Text("List"),
                    )
                  ],
                ),
                onTap: () {
                  // Handle 'List' option tap
                },
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.person_2_outlined, color: Colors.black),
                    Container(
                      margin: EdgeInsets.only(left: 10),
                      child: Text("Profil"),
                    )
                  ],
                ),
                onTap: () {
                  // Handle 'Profil' option tap
                },
              ),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.white10, Colors.white24, Color.fromARGB(255, 4, 87, 155)],
            ),
          ),
          child: ListView.builder(
            itemCount: notes.length,
            itemBuilder: (context, index) {
              return Dismissible(
                key: Key(notes[index]),
                onDismissed: (direction) {
                  _deleteNote(index);
                },
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: 250,
                    height: 120,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Color.fromARGB(255, 41, 41, 41),
                        width: 2,
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              notes[index],
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () {
                            _editNote(index);
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () {
                            _deleteNote(index);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNote,
        child: Icon(Icons.add),
      ),
    );
  }
}

class AddNoteScreen extends StatelessWidget {
  final TextEditingController _textEditingController = TextEditingController();
  final TextEditingController _contentEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var time = DateFormat('d MMMM, yyyy. hh:mm a').format(DateTime.now());
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 17, 36, 69),
        title: Text('Add Barang Kosong'),
      ),
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.white10, Colors.white24, Color.fromARGB(255, 4, 87, 155)],
          )),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: 20),
                Container(
                  width: 480,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 3,
                        blurRadius: 10,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 12,
                      ),
                      Icon(Icons.date_range_outlined),
                      Text("\t $time"),
                    ],
                  ),
                ),
                SizedBox(height: 25),
                TextFormField(
                  controller: _textEditingController,
                  style: TextStyle(fontSize: 15, color: Colors.black),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.person_outline_outlined),
                    labelText: "Masukan Nama Karyawan",
                    hintText: "Masukan Nama Karyawan",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    fillColor: Color.fromARGB(255, 246, 247, 248),
                    filled: true,
                  ),
                ),
                SizedBox(height: 25),
                TextField(
                  controller: _contentEditingController,
                  maxLines: 3,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.note_add),
                    fillColor: const Color.fromARGB(255, 231, 101, 101),
                    hintText: "Description",
                    labelText: "Description",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                ),
                SizedBox(height: 16.0),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.blue),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      String title = _textEditingController.text;
                      String content = _contentEditingController.text;
                      String note = '$time \n Nama Karyawan : $title \n Barang Kosong :  $content';
                      Navigator.pop(context, note);
                    },
                    child: Text('Add Note'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class EditNoteScreen extends StatefulWidget {
  final String note;

  EditNoteScreen({required this.note});

  @override
  _EditNoteScreenState createState() => _EditNoteScreenState();
}

class _EditNoteScreenState extends State<EditNoteScreen> {
  late TextEditingController _textEditingController;
  late TextEditingController _contentEditingController;

  @override
  void initState() {
    super.initState();
    List<String> noteParts = widget.note.split('\n');
    String title = noteParts[1].trim().split(': ')[1];
    String content = noteParts[2].trim().split(': ')[1];
    _textEditingController = TextEditingController(text: title);
    _contentEditingController = TextEditingController(text: content);
  }

  @override
  void dispose() {
    _textEditingController.dispose();
    _contentEditingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 17, 36, 69),
        title: Text('Edit Barang Kosong'),
      ),
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.white10, Colors.white24, Color.fromARGB(255, 4, 87, 155)],
          )),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _textEditingController,
                  decoration: InputDecoration(
                    labelText: 'Nama Karyawan',
                  ),
                ),
                TextField(
                  controller: _contentEditingController,
                  maxLines: 3,
                  decoration: InputDecoration(
                    labelText: 'Description',
                  ),
                ),
                SizedBox(height: 16.0),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.blue),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      String title = _textEditingController.text;
                      String content = _contentEditingController.text;
                      String note = '${DateTime.now()} \n Nama Karyawan : $title \n Barang Kosong :  $content';
                      Navigator.pop(context, note);
                    },
                    child: Text('Edit Note'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
