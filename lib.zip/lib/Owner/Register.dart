import 'package:cth/Owner/Login.dart';
import 'package:cth/Owner/vertifikasi.dart';
import 'package:flutter/material.dart';

class Register extends StatefulWidget {
  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  String _jk = "";

  void _pilihJk(String value) {
    setState(() {
      _jk = value;
    });
  }


  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SafeArea(
          child: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white10,
                  Colors.white24,
                  Color.fromARGB(255, 4, 87, 155)
                ],
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Column(
                          children: [  
                            SizedBox(
                              child: Column(
                                children: [
                                  Image(
                                    image: AssetImage("images/38.png"),
                                    height: 128,
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              width: 480,
                              height: 50,
                              child: 
                                 Row(
                  children: [
                    Text("Register",style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 20,color: Colors.black,
                      ),),
                  ],
                 ),
                            ),
                            
                          ],
                        ),
                      ],
                    ),
                  ),
                  Column(
                    children: [
                       TextFormField(
                          style: TextStyle(
                  fontSize: 15, color: Colors.black
                ),
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.email_sharp),
                            labelText: "Masukan Email Anda",
                            hintText: "Masukan Email Anda",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(20),
                      ),
                      borderSide: BorderSide.none
                            ), 
                            fillColor: Color.fromARGB(255, 207, 212, 245),
                          filled: true,
                          ),
                        ),
                        SizedBox(height: 25,),
                       TextFormField(
                          style: TextStyle(
                  fontSize: 15, color: Colors.black
                ),
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.person_outline_outlined),
                            labelText: "Masukan Username Anda",
                            hintText: "Masukan Username Anda",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(20),
                      ),
                      borderSide: BorderSide.none
                            ), 
                            fillColor: Color.fromARGB(255, 207, 212, 245),
                          filled: true,
                          
                          ),
                        ),
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "\t\t\t\tJenis Kelamin",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  RadioListTile(
                    value: "Laki - Laki",
                    title: Text("Laki - Laki"),
                    groupValue: _jk,
                    onChanged: (String? value) {
                      if (value != null) {
                        _pilihJk(value);
                      }
                    },
                  ),
                  RadioListTile(
                    value: "Perempuan",
                    title: Text("Perempuan"),
                    groupValue: _jk,
                    onChanged: (String? value) {
                      if (value != null) {
                        _pilihJk(value);
                      }
                    },
                  ),
                Column(
                  children: [
                    
                        SizedBox(height: 5,),
                        TextFormField(
                          style: TextStyle(
                  fontSize: 15, color: Colors.black
                ),
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.lock_outline),
                            labelText: "Masukan Kata Sandi",
                            hintText: "Masukan Kata Sandi",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(20),
                      ),
                      borderSide: BorderSide.none
                            ), 
                            fillColor: Color.fromARGB(255, 207, 212, 245),
                            suffixIcon: IconButton(onPressed: null, icon: Icon(Icons.remove_red_eye_sharp)),
                          filled: true,
                          ),
                        ),
                  ],
                ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      child: MaterialButton(
                        height: 40,
                        minWidth: 200,
                        onPressed: () {
                           Navigator.push(context, MaterialPageRoute(builder: (context)=>   Vertifikasi()));
                        },
                        color: Color.fromARGB(255, 4, 87, 155),
                        shape: RoundedRectangleBorder(
                          side:
                              BorderSide(color: const Color.fromARGB(255, 249, 252, 255)),
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: Text(
                          "Daftar",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),
                  ),
                    Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: SizedBox(
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      SizedBox(width: 130,),
                                      Text("Don't have on account?"),
                                      GestureDetector(
                                        onTap: () {
                                    Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => LoginOwner()));},
                                        child: Text("Login",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
