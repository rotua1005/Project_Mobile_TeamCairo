import 'package:cth/Owner/Login.dart';
import 'package:flutter/material.dart';

class Vertifikasi extends StatefulWidget {
  @override
  State<Vertifikasi> createState() => _VertifikasiState();
}

class _VertifikasiState extends State<Vertifikasi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 17, 36, 69),
        title: Text("Vertifikasi Akun "),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SafeArea(
          child: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white10,
                  Colors.white24,
                  Color.fromARGB(255, 4, 87, 155)
                ],
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                 Center(
                 child: Image(
                                    image: AssetImage("images/shop.png"),
                                    height: 308,
                                  ),
                 ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      TextField(
                        // keyboardAppearance: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          hintText: "Enter Email",
                          labelText: "Email",
                          fillColor: Colors.black,
                          suffixIcon: TextButton(onPressed: () {  },
                          child: Text("Send OTP",style: TextStyle(fontWeight: FontWeight.bold),),)
                        ),
                      ),
                      SizedBox(height: 30.0,),
                       TextField(
                        // keyboardAppearance: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          hintText: "OTP",
                          labelText: "Masukan OTP",
                         
                        ),
                      ),
                    ],
                  ),
                ),
                 Padding(
                    padding: const EdgeInsets.all(11.0),
                    child: Container(
                      child: MaterialButton(
                        height: 40,
                        minWidth: 200,
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => LoginOwner()));
                        },
                        color: Color.fromARGB(255, 4, 87, 155),
                        shape: RoundedRectangleBorder(
                          side:
                              BorderSide(color: const Color.fromARGB(255, 249, 252, 255)),
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: Text(
                          "Submit",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,color: Colors.white
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
