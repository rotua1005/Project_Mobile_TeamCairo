import 'package:cth/Owner/Register.dart';
import 'package:cth/Owner/menu_owner.dart';
import 'package:flutter/material.dart';

class LoginOwner extends StatefulWidget {
  const  LoginOwner({super.key});

  @override
  State< LoginOwner> createState() =>  _LoginOwnerState();
}

class  _LoginOwnerState extends State< LoginOwner> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.white10,Colors.white24,Color.fromARGB(255, 4, 87, 155)],
            ),
            ),
            child: SingleChildScrollView(
              child: Padding(
                      padding: const EdgeInsets.all(9.0),
                      child: Column(
                children: <Widget>[
                  Column(
                       mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 1),
                Image(image: AssetImage(
                  "images/38.png"),height: 128),
                  SizedBox(height: 20,),
                Text("BRASTAGI ACC PONSEL",style: TextStyle(
                  fontSize: 25,fontWeight: FontWeight.bold
                ),
                ),
                Text("Menyediakan Kebutuhan Anda",style: TextStyle(
                  fontSize: 15,fontWeight: FontWeight.normal,color: Colors.blueAccent
                ),
                ),
                SizedBox(height: 10,),
                 Row(
                  children: [
                    Text("   Login",style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 20,color: Colors.black,
                      ),),
                  ],
                 ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Form(
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 20.0),
                      child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                          style: TextStyle(
                  fontSize: 15, color: Colors.black
                ),
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.person_outline_outlined),
                            labelText: "Masukan Username",
                            hintText: "Masukan Username",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(20),
                      ),
                      borderSide: BorderSide.none
                            ), 
                            fillColor: Color.fromARGB(255, 207, 212, 245),
                          filled: true,
                          
                          ),
                          
                        ),
                       
                        SizedBox(height: 25,),
                        TextFormField(
                           obscureText: true,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.lock_outline),
                            labelText: "Masukan Kata Sandi",
                            hintText: "Masukan Kata Sandi", 
                            border: OutlineInputBorder(
                               borderRadius: BorderRadius.all(Radius.circular(20),
                      ),
                      borderSide: BorderSide.none
                            ),
                            suffixIcon: IconButton(onPressed: null, icon: Icon(Icons.remove_red_eye_sharp)),
                              fillColor: Color.fromARGB(255, 207, 212, 245),
                          filled: true, 
                            ),
                          ),
                      ],
                                  ),
                    )),
                ),
                  Column(
                    children: <Widget>[
                      Column(
                        children: [
                          MaterialButton(
                            minWidth: 200,
                            height: 50,
                            onPressed: () {
                               Navigator.push(context, MaterialPageRoute(builder: (context)=>  const MenuOwner()));
                            },
                            color: Color.fromARGB(255, 4, 87, 155),
                          shape : RoundedRectangleBorder(
                            side: BorderSide(
                              color: const Color.fromARGB(255, 4, 87, 155)
                            ),
                            borderRadius: BorderRadius.circular(50)
                          ),
                          child: Text("Login",style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20,color: Colors.white,
                          ),),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: SizedBox(
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      SizedBox(width: 130,),
                                      Text("Don't have on account?"),
                                      GestureDetector(
                                        onTap: () {
                                     Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => Register()));
                                    },
                                        child: Text("Register",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    
              ],
                  ),
                  SizedBox(height: 125,),
                  Column(
                    children: [
                      Text("Forget Password",style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 12,
                      ),),
                    ],
                  )
              ],
                    ),
                ]),
                  ),
            ))));
  }
}