import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:intl/intl.dart';

class ListAbsensi extends StatefulWidget {
  final String nama;
  final String pass;
  final String alasan;
  final String jk;
  const ListAbsensi({super.key, required this.nama, required this.pass, required this.alasan, required this.jk});

  @override
  State<ListAbsensi> createState() => _ListAbsensiState();
}

class _ListAbsensiState extends State<ListAbsensi> {
  @override
  Widget build(BuildContext context) {
    var time = DateFormat('d MMMM, yyyy. hh:mm a').format(DateTime.now());
    return Scaffold(
      bottomNavigationBar: Container(
        color: const Color.fromARGB(255, 17, 36, 69),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 1.0,vertical: 5),
          child: GNav(
            backgroundColor: const Color.fromARGB(255, 17, 36, 69),
            color: Colors.white,
            activeColor: Colors.white,
            tabBackgroundColor: Colors.grey.shade800,
            gap: 10,
            onTabChange: (index){
              print(index);
            },
            padding: EdgeInsets.all(12),
            tabs: [
            GButton(icon: Icons.home,text: "Home",onPressed: () {
                            // Navigator.push(context, MaterialPageRoute(builder: (context)=>  const Home()));
                          },),
            GButton(icon: Icons.shopping_cart_checkout,text: "Penjualan",onPressed: () {
                            // Navigator.push(context, MaterialPageRoute(builder: (context)=>  const Produk()));
                          },),
            GButton(icon: Icons.list_alt,text: "Absensi",onPressed: () {
                            //  Navigator.push(context, MaterialPageRoute(builder: (context)=>  Absensi()));
                          },),
            GButton(icon: Icons.note_alt_sharp,text: "Note",onPressed: () {
                            //  Navigator.push(context, MaterialPageRoute(builder: (context)=>  const Note()));
                          },),
          ]),
        ),
      ),
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.white10,
                Colors.white24,
                Color.fromARGB(255, 4, 87, 155),
              ],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child:Column(
              children: [
                Column(
                  children: [
                    Container(
                                 width: 450,
                                height: 120,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: Color.fromARGB(255, 41, 41, 41),
                                    width: 2
                                  ),
                                ),
                                child: SizedBox(
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Row(
                                          children: [
                                            Text("$time",style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold,color: Colors.grey),),
                                          ],
                                        ),
                                      ),
                                        SizedBox(
                                        height: 25,
                                  child: Row(
                                    children: [
                                       Text("Nama \t\t\t\t\t\t\t: ${widget.nama}",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
                                    ],
                                  ),
                                ),
                                      SizedBox(
                                        height: 25,
                                  child: Row(
                                    children: [
                                       Text("Kehadiran : ${widget.jk}",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                        height: 25,
                                  child: Row(
                                    children: [
                                       Text("Alasan \t\t\t\t\t\t: ${widget.alasan}",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
                                    ],
                                  ),
                                ),
                                    ],
                                  ),
                                ),
                             ),
                  ],
                ),
              ],
            ),
            //  Row(
            //   children: [
            //     Text("Alasan   : ${widget.alasan}"),
            //     Text("Alasan   : ${widget.jk}"),
            //   ],
            // ),
          ),
        ),
      ),
      appBar: AppBar(title: Text("List Absensi"),),
    );
  }
}