import 'package:cth/Karyawan/menu.dart';
import 'package:cth/welcome.dart';
import 'package:flutter/material.dart';

class Profil extends StatefulWidget {
  const Profil({Key? key});

  @override
  State<Profil> createState() => _ProfilState();
}

class _ProfilState extends State<Profil> {
  Widget logoutButton() {
    return InkWell(
      onTap: () {
          Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => Welcome()));
      },
      child: Container(
        color:  const Color.fromARGB(255, 17, 36, 69),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [Icon(Icons.logout,color: Colors.white,),Text("Logout",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),)],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.white10,
                Colors.white24,
                Color.fromARGB(255, 4, 87, 155),
              ],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(9.0),
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                         onTap: () {
          Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => Menu()));},
                        child: Row(
                          children: [
                            Icon(Icons.arrow_back_ios,),
                            
                          ],
                        ),
                      ),
                      SizedBox(height: 1),
                      Image(
                        image: AssetImage("images/Ellipse 1.png"),
                        height: 128,
                      ),
                      SizedBox(height: 20,),
                      Text(
                        "Tomy Andreas",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 30,),
                      Row(
                        children: [
                          Text(
                            "   Personal Details",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(0.0),
                        child: Card(
                          color: Colors.lightBlueAccent,
                          elevation: 3,
                          child: Column(
                            children: [
                              ListTile(
                                leading: Icon(Icons.email),
                                title: Text(
                                  "tomy@gmail.com",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              Divider(
                                height: 12,
                                color: Colors.black,
                              ),
                              ListTile(
                                leading: Icon(Icons.phone),
                                title: Text(
                                  "08124324567",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                              Divider(
                                height: 12,
                                color: Colors.black,
                              ),
                              ListTile(
                                leading: Icon(Icons.location_on),
                                title: Text(
                                  "08124324567",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
            
                      SizedBox(height: 45,),
                      Row(
                        children: [
                          Text(
                            "   Setting",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(0.0),
                        child: Card(
                          color: Colors.lightBlueAccent,
                          elevation: 4,
                          child: Column(
                            children: [
                              ListTile(
                                leading: Icon(Icons.settings),
                                title: Text(
                                  "Settings",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              Divider(
                                height: 12,
                                color: Colors.black,
                              ),
                              ListTile(
                                leading: Icon(Icons.grid_on_sharp),
                                title: Text(
                                  "About Us",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      SizedBox(height: 35,),
                      logoutButton(),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
