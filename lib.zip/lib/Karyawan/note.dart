import 'package:cth/Karyawan/absensi.dart';
import 'package:cth/Karyawan/create.dart';
import 'package:cth/Karyawan/menu.dart';
import 'package:cth/Karyawan/profil.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class Note extends StatefulWidget {
  const Note({Key? key}) : super(key: key);

  @override
  State<Note> createState() => _NoteState();
}

class _NoteState extends State<Note> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 17, 36, 69),
        title: Text("Stok Barang"),
        actions: [
          PopupMenuButton(
            icon: const Icon(Icons.more_horiz),
            itemBuilder: (context) => [
              PopupMenuItem(
                child: GestureDetector(
                  onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) => NoteListScreen()),
                  );
                },
                  child: Row(
                    children: [
                      Icon(
                        Icons.create_outlined,
                        color: Colors.black,
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 10),
                        child: Text("Create"),
                      )
                    ],
                  ),
                ),
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    Icon(
                      Icons.list_outlined,
                      color: Colors.black,
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 10),
                      child: Text("List"),
                    )
                  ],
                ),
              ),
              PopupMenuItem(
                child: GestureDetector(
                  onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) => Profil()),
                  );
                },
                  child: Row(
                    children: [
                      Icon(
                        Icons.person_2_outlined,
                        color: Colors.black,
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 10),
                        child: Text("Profil"),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: Container(
        color: const Color.fromARGB(255, 17, 36, 69),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 1.0, vertical: 5),
          child: GNav(
            backgroundColor: const Color.fromARGB(255, 17, 36, 69),
            color: Colors.white,
            activeColor: Colors.white,
            tabBackgroundColor: Colors.grey.shade800,
            gap: 10,
            onTabChange: (index) {
              print(index);
            },
            padding: EdgeInsets.all(12),
            tabs: [
              GButton(
                icon: Icons.home,
                text: "Home",
                onPressed: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>  Menu()));
                },
              ),
              GButton(
                icon: Icons.shopping_cart_checkout,
                text: "Penjualan",
                onPressed: () {},
              ),
              GButton(
                icon: Icons.list_alt,
                text: "Absensi",
                onPressed: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>  Absensi()));
                },
              ),
              GButton(
                icon: Icons.note_alt_sharp,
                text: "Note",
                onPressed: () {},
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.white10,
                Colors.white24,
                Color.fromARGB(255, 4, 87, 155),
              ],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(9.0),
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  SizedBox(height: 20),
                  Text(
                    "Note Stok Barang",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 0),
                  Image(
                    image: AssetImage("images/Team work_Monochromatic 1.png"),
                    height: 328,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
