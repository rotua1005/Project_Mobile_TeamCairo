import 'package:cth/Karyawan/Space.dart';
import 'package:cth/Owner/ListAbsensi.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profil.dart';


class Absensi extends StatefulWidget {
  @override
  State<Absensi> createState() => _AbsensiState();
}

class _AbsensiState extends State<Absensi> {
  String _jk = "";
  TextEditingController controllerNama = TextEditingController();
  TextEditingController controllerPass = TextEditingController();
  TextEditingController controllerMoto = TextEditingController();

  void _pilihJk(String value) {
    setState(() {
      _jk = value;
    });
  }

  void kirimdata() async {
    var prefs = await SharedPreferences.getInstance();
    var time = DateFormat('d MMMM, yyyy. hh:mm a').format(DateTime.now());
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: Container(
            height: 130.0,
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Text("$time"),
                  Text("Nama Lengkap  : Tomy Andreas"),
                  Text("Kehadiran    : $_jk"),
                  Text("Alasan   : ${controllerMoto.text}"),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          child: MaterialButton(
                            height: 40,
                            minWidth: 200,
                            onPressed: () { 
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => Space( nama: 'Tomy Andreas',
                              pass: '',
                              alasan: controllerMoto.text,
                              jk: _jk,)
                          ));
                        
                            },
                            color: Color.fromARGB(255, 4, 87, 155),
                            shape: RoundedRectangleBorder(
                              side: BorderSide(
                                  color: const Color.fromARGB(255, 249, 252, 255)),
                              borderRadius: BorderRadius.circular(50),
                            ),
                            child: Text(
                              "Submit",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    var time = DateFormat('d MMMM, yyyy. hh:mm a').format(DateTime.now());
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 17, 36, 69),
        title: Text("Form Absensi "),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (BuildContext context) => Profil(),
              ));
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("$time"),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SafeArea(
          child: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white10,
                  Colors.white24,
                  Color.fromARGB(255, 4, 87, 155)
                ],
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Column(
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                            ),
                            SizedBox(
                              child: Column(
                                children: [
                                  Image(
                                    image: AssetImage("images/38.png"),
                                    height: 128,
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Text(
                                    "Absensi Karyawan",
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 20),
                            Container(
                              width: 480,
                              height: 50,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.5),
                                    spreadRadius: 3,
                                    blurRadius: 10,
                                    offset: Offset(0, 3),
                                  )
                                ],
                              ),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: 12,
                                  ),
                                  Text("Tomi Andreas"),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "\t\t\tKehadiran",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  RadioListTile(
                    value: "Hadir",
                    title: Text("Hadir"),
                    groupValue: _jk,
                    onChanged: (String? value) {
                      if (value != null) {
                        _pilihJk(value);
                      }
                    },
                  ),
                  RadioListTile(
                    value: "Tidak Hadir",
                    title: Text("Tidak Hadir"),
                    groupValue: _jk,
                    onChanged: (String? value) {
                      if (value != null) {
                        _pilihJk(value);
                      }
                    },
                  ),
                  RadioListTile(
                    value: "Terlambat",
                    title: Text("Terlambat"),
                    groupValue: _jk,
                    onChanged: (String? value) {
                      if (value != null) {
                        _pilihJk(value);
                      }
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.all(7.0),
                    child: TextField(
                      controller: controllerMoto,
                      maxLines: 3,
                      decoration: InputDecoration(
                        fillColor: const Color.fromARGB(255, 231, 101, 101),
                        hintText: "Alasan Terlambat / Tidak Hadir",
                        labelText: "Alasan Terlambat / Tidak Hadir",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: GestureDetector(
                       onTap: () { 
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => ListAbsensi( nama: 'Tomy Andreas',
                              pass: '',
                              alasan: controllerMoto.text,
                              jk: _jk,)
                          ));
                        
                            },
                      child: Container(
                        child: MaterialButton(
                          height: 40,
                          minWidth: 200,
                          onPressed: () {
                            kirimdata();
                             Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => ListAbsensi( nama: 'Tomy Andreas',
                              pass: '',
                              alasan: controllerMoto.text,
                              jk: _jk,)
                          ));
                        
                          },
                          color: Color.fromARGB(255, 4, 87, 155),
                          shape: RoundedRectangleBorder(
                            side: BorderSide(
                                color: const Color.fromARGB(255, 249, 252, 255)),
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: Text(
                            "Submit",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

